import acm.program.*;
import acm.util.*;

public class Craps extends ConsoleProgram{
	public void run() {
		int total = rollTwoDice();
		if (total == 7 || total == 11) {
			println("win");
		} else if (total == 2 || total == 3 || total == 12) {
			println("Crap! you lose");
		} else {
			int point = total;
			println("you got " + point + " points");
			while (true) {
				println("roll again");
				total = rollTwoDice();
				if (point == total) {
					println("you got same point 2nd time, win");
					break;
				} else if (total == 7) {
					println("you got 7, lose");
					break;
				}
			}
			
			
		}
	}
	
	private int rollTwoDice() {
		int d1 = rgen.nextInt(1, 6);
		int d2 = rgen.nextInt(1, 6);
		int total = d1 + d2;
		println("Rolling Dice " + d1 + " , " + d2);
		return total;
	}
	
	private RandomGenerator rgen = new RandomGenerator();
}
