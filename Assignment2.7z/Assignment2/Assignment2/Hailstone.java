/*
 * File: Hailstone.java
 * --------------------
 * This program is a stub for the Hailstone problem, which computes
 * Hailstone sequence described in Assignment #2.
 */

import acm.program.*;

public class Hailstone extends ConsoleProgram {

	public void run() {
		// You fill this in
		int n = readInt("Enter a number: ");  /*user type in n */
		int num = 0;                          /*record how many steps */
		while (n != 1) {
			int r = n % 2;
			/*
			 * if n is even, diivide n by 2
			 * if n is odd, multiplies n by 3 and plus 1
			 */
			if (r == 0) {
				println(n + " is even, so I make half = " + (n / 2));
				n /= 2;
			} else if (r != 0) {
				println(n + " is odd, so I make 3n+1 = " + (n * 3 + 1));
				n = n * 3 + 1;
			}
			num++;
		}
		println("The process took " + num + " steps to reach 1.");
		
		
	}

}
