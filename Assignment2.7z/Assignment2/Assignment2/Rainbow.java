/*
 * File: Rainbow.java
 * ------------------
 * This program is a stub for the Rainbow problem, which displays
 * a rainbow by adding consecutively smaller circles to the canvas.
 */
import acm.graphics.*;
import acm.program.*;
import java.awt.*;
public class Rainbow extends GraphicsProgram {
	private static final int ARCH_NUM = 6;
	private static final int OFFSET_Y = 10;
	public void run() {
		// You fill this in
		/*
		 * draw the background- light blue
		 */
		int h = getHeight();
		int w = getWidth();
		GRect window = new GRect(0, 0, w, h);
		window.setFilled(true);
		window.setColor(Color.CYAN);
		add(window);
		/*
		 * draw circles
		 */
		int rMin = (int) Math.sqrt((w / 2) * (w / 2) + OFFSET_Y * OFFSET_Y);
		int rMax = OFFSET_Y + h;
		int delta = (h - rMin) / (ARCH_NUM + 1);
	
		//GOval oval1 = circle (100, 100, 50);
		addColorCircle(w / 2, OFFSET_Y + h, rMin + 6 * delta + 5, Color.RED);
		addColorCircle(w / 2, OFFSET_Y + h, rMin + 5 * delta + 5, Color.ORANGE);
		addColorCircle(w / 2, OFFSET_Y + h, rMin + 4 * delta + 5, Color.YELLOW);
		addColorCircle(w / 2, OFFSET_Y + h, rMin + 3 * delta + 5, Color.GREEN);
		addColorCircle(w / 2, OFFSET_Y + h, rMin + 2 * delta + 5, Color.BLUE);
		addColorCircle(w / 2, OFFSET_Y + h, rMin + 1 * delta + 5, Color.MAGENTA);
		addColorCircle(w / 2, OFFSET_Y + h, rMin + 0 * delta + 5, Color.CYAN);
	}
	private void addColorCircle (int x, int y, int r, Color color) {
		GOval oval = new GOval(x - r, y - r, r * 2, r * 2);
		oval.setFilled(true);
		oval.setColor(color);
		add(oval);
	}

}
