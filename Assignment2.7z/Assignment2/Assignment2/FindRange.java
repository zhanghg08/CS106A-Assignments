/*
 * File: FindRange.java
 * --------------------
 * This program is a stub for the FindRange problem, which finds the
 * smallest and largest values in a list of integers.
 */

import acm.program.*;

public class FindRange extends ConsoleProgram {
private static final int SENTINEL = 0;
	public void run() {
		// You fill this in
		println("Prompt and instructions:");
		int max = 0;
		int min = 0;
		while (true) {
			int a = readInt(" ? ");
			if (a == SENTINEL) {
				break;
			} 
			if (max == 0) {
				max = a;
			}
			if (min == 0) {
				min = a;
			}
			if (a > max) {
				max = a;
			} else if (a < min) {
				min = a;
			}
		}
		println("The smallest value is " + min);
		println("The largest value is " + max);
	}

}
