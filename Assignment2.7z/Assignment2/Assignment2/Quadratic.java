/*
 * File: Quadratic.java
 * --------------------
 * This program is a stub for the Quadratic problem, which finds the
 * roots of the quadratic equation.
 */

import acm.program.*;

public class Quadratic extends ConsoleProgram {
	private static final double SENTINEL = 0;
	public void run() {
		// You fill this in
		println("Enter coefficients for the quadratic equation:");
		double a = readDouble("a: ");
		while (a == SENTINEL) {
			a = readDouble("a should not be 0, please type in a again:");
		}
		double b = readDouble("b: ");
		double c = readDouble("c: ");
		if (b * b - 4 * a * c < 0) {
			println("There is no real solution.");
		} else if (b * b - 4 * a * c == 0){
			println("The two solutions are same. They are " + (-b / 2 / a));
		} else {
			double sqRoot = Math.sqrt(b * b - 4 * a * c);
			println("The first solution is " + (-b + sqRoot) / 2 / a);
			println("The second solution is " + (-b - sqRoot) / 2 / a);
		}
	}

}

