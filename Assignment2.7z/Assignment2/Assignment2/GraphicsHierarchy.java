/*
 * File: GraphicsHierarchy.java
 * ----------------------------
 * This program is a stub for the GraphicsHierarchy problem, which
 * draws a partial diagram of the acm.graphics hierarchy.
 */

import acm.program.*;
import acm.graphics.*;

public class GraphicsHierarchy extends GraphicsProgram {
	private static final int WIDTH_BOX = 80;
	private static final int HEIGHT_BOX = 50;
	public void run() {
		// You fill this in
		// get window height and width
		int hWindow = getHeight();
		int wWindow = getWidth();
		
		//create Rect 1-5
		int d = (wWindow / 4 - WIDTH_BOX) / 2;
		int xRect1 = wWindow / 2 - WIDTH_BOX / 2;
		int yRect1 = hWindow / 4 - HEIGHT_BOX / 2;
		int xRect2 = d;
		int yRect2 = hWindow / 4 * 3 - HEIGHT_BOX / 2;
		int xRect3 = wWindow / 4 + d;
		int yRect3 = hWindow / 4 * 3 - HEIGHT_BOX / 2;
		int xRect4 = wWindow / 2 + d;
		int yRect4 = hWindow / 4 * 3 - HEIGHT_BOX / 2;
		int xRect5 = wWindow / 4 * 3 + d;
		int yRect5 = hWindow / 4 * 3 - HEIGHT_BOX / 2;
		GRect rect1 = new GRect(xRect1, yRect1, WIDTH_BOX, HEIGHT_BOX);
		add(rect1);
		GRect rect2 = new GRect(xRect2, yRect2, WIDTH_BOX, HEIGHT_BOX);
		add(rect2);
		GRect rect3 = new GRect(xRect3, yRect3, WIDTH_BOX, HEIGHT_BOX);
		add(rect3);
		GRect rect4 = new GRect(xRect4, yRect4, WIDTH_BOX, HEIGHT_BOX);
		add(rect4);
		GRect rect5 = new GRect(xRect5, yRect5, WIDTH_BOX, HEIGHT_BOX);
		add(rect5);
		
		//create Label 1-5
		GLabel label1 = new GLabel("GObject");
		double xLabel1 = wWindow / 2 - label1.getWidth() / 2;
		double yLabel1 = hWindow / 4 + label1.getAscent() / 2;
		label1.setLocation(xLabel1, yLabel1);
		add(label1);
		
		GLabel label2 = new GLabel("GLabel");
		double xLabel2 =Math.abs(label2.getWidth() - WIDTH_BOX) / 2 + xRect2;
		double yLabel2 = hWindow / 4 * 3 + label2.getAscent() / 2;
		label2.setLocation(xLabel2, yLabel2);
		add(label2);
		
		GLabel label3 = new GLabel("GLine");
		double xLabel3 =Math.abs(label3.getWidth() - WIDTH_BOX) / 2 + xRect3;
		double yLabel3 = hWindow / 4 * 3 + label3.getAscent() / 2;
		label3.setLocation(xLabel3, yLabel3);
		add(label3);
		
		GLabel label4 = new GLabel("GOval");
		double xLabel4 =Math.abs(label4.getWidth() - WIDTH_BOX) / 2 + xRect4;
		double yLabel4 = hWindow / 4 * 3 + label4.getAscent() / 2;
		label4.setLocation(xLabel4, yLabel4);
		add(label4);
		
		GLabel label5 = new GLabel("GRect");
		double xLabel5 = Math.abs(label5.getWidth() - WIDTH_BOX) / 2 + xRect5;
		double yLabel5 = hWindow / 4 * 3 + label5.getAscent() / 2;
		label5.setLocation(xLabel5, yLabel5);
		add(label5);
		
		//create line
		add(new GLine((xRect1 + WIDTH_BOX / 2), yRect1 + HEIGHT_BOX, xRect2 + WIDTH_BOX / 2, yRect2));
		add(new GLine((xRect1 + WIDTH_BOX / 2), yRect1 + HEIGHT_BOX, xRect3 + WIDTH_BOX / 2, yRect3));
		add(new GLine((xRect1 + WIDTH_BOX / 2), yRect1 + HEIGHT_BOX, xRect4 + WIDTH_BOX / 2, yRect4));
		add(new GLine((xRect1 + WIDTH_BOX / 2), yRect1 + HEIGHT_BOX, xRect5 + WIDTH_BOX / 2, yRect5));
	}

}
