import acm.program.*;
public class practice extends ConsoleProgram {
	public void run() {
		int x = readInt("Enter number x:  ");
		int y = readInt("Enter number y:  ");
		println("Greatest Common Divisor of x and y is " + gcd(x, y));
	}
	
	private int combinations (int n, int k) {
		return factorial(n) / (factorial(k) * factorial(n-k));
	}
	
	private int factorial (int n) {
		int result = 1;
		for (int i = 1; i <= n; i++) {
			result *= i;
		}
		return result;
	}
	
	private int gcd_brutal (int x, int y) {
		int guess = Math.min(x, y);
		while ((x % guess != 0) || (y % guess != 0)) {
			guess--;
		}
		return guess;
	}
	
	private int gcd (int x, int y) {
		int r = x % y;
		while (r != 0) {
			x = y;
			y = r;
			r = x % y;
		}
		return y;
	}

}
