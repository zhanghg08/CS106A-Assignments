/*
 * File: Pyramid.java
 * ------------------
 * This program is a stub for the Pyramid problem, which draws
 * a brick pyramid.
 */

import acm.graphics.GRect;
import acm.program.*;

public class Pyramid extends GraphicsProgram {
	private static final int BRICK_WIDTH = 30;
	private static final int BRICK_HEIGHT = 12;
	private static final int BRICKS_IN_BASE = 12;
	public void run() {
		// You fill this in
		int bottom = getHeight();
		for (double i = 0; i < BRICKS_IN_BASE; i++) {
			for (double j = 0; j < (BRICKS_IN_BASE - i); j++) {
				double x = getWidth() / 2 - BRICK_WIDTH * BRICKS_IN_BASE / 2 + i / 2 * BRICK_WIDTH + j * BRICK_WIDTH;
				double y = bottom - BRICK_HEIGHT * (i + 1);
				GRect brick = new GRect(x, y, BRICK_WIDTH, BRICK_HEIGHT);
				add(brick);
				
			}
		}
	}

}
