import acm.program.*;
import acm.util.*;

public class SimpleRandom extends ConsoleProgram{
	public void run() {
		//rgen.setSeed(0);
		double dieRoll = rgen.nextDouble();
		println("You rolled " + dieRoll);
		Rational a = new Rational(1, 2);
		Rational b = new Rational(1, 3);
		Rational c = new Rational(1, 6);
		Rational sum = a.add(b).add(c);
		println(a + " + " + b + " + " + c + " = " + sum);
	}
	private RandomGenerator rgen = new RandomGenerator();
}
